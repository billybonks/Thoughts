﻿App.Link = DS.Model.extend({
    title: DS.attr('string'),
});

App.Link.FIXTURES = [
 {
     id: 1,
     title: 'www.plantgrowers.com',

 },
 {
     id: 2,
     title: 'www.soilQualityTutorials.com',
 },
 {
     id: 3,
     title: 'www.plantsteraformers.com',
 }
];