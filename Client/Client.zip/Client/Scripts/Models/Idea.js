﻿App.Idea = DS.Model.extend({
    title: DS.attr('string'),
    description: DS.attr('string'),
    documents: DS.hasMany('document', { async: true }),
    links: DS.hasMany('link', { async: true }),
    left: DS.attr('int'),
    top: DS.attr('int'),
    comments: DS.hasMany('comment', { async: true }),
    user: DS.belongsTo('user', { async: true }),
    test: function () {
        this.get('links').forEach(function (entry) {
            console.log('title');
        });
    }.property('links')
});

App.Idea.FIXTURES = [
 {
     id: 1,
     title: 'title',
     description: 'asdadasdasdads',
     documents: [1],
     links: [1,2],
     comments: [1],
     user: 1,
     left: '0',
     top: '0'

 },
 {
     id: 2,
     title: 'asdadasd',
     description: 'asdadasdasdadasdasdadasdasdadasdasdadasdasdadasd',
     documents: [2],
     links: [2],
     comments: [2],
     user: 1,
     left: '600',
     top: '0'
 },
 {
     id: 3,
     title: 'Why is a interactive board cool',
     description: 'Dynamically allows you to ',
     documents: [3],
     links: [3],
     comments: [3],
     user: 1,
     left: '1200',
     top: '0'
 }
];