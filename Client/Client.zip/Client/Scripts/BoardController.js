﻿function BoardController() {
    var ideaElement
    //refernce idea block
    //bind mouse move event
        //on mouse move
        //if dragging
        //drag bound ideablock

}

BoardController.prototype.StartDarg = function (var ideaID) {
    console.log('start');
}

BoardControler.prototype.StopDrag = function () {
    //bind mouseup to dragger +- body
        //on mouse up stop drag

}