﻿App.IdeasController = Ember.ArrayController.extend({
});